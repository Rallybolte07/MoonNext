/* MOONNEXT — local-seo.html page script */
MN.run(function (fx) {
  fx.headings();fx.stagger('.svc-lists li,.check li');
});
